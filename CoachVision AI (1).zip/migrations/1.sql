
CREATE TABLE users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  mocha_user_id TEXT NOT NULL UNIQUE,
  email TEXT NOT NULL,
  name TEXT,
  role TEXT NOT NULL DEFAULT 'athlete', -- 'athlete' or 'coach'
  subscription_plan TEXT NOT NULL DEFAULT 'free', -- 'free' or 'pro'
  analyses_used_this_week INTEGER DEFAULT 0,
  week_reset_date DATE,
  profile_picture_url TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE videos (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  title TEXT NOT NULL,
  description TEXT,
  video_url TEXT NOT NULL,
  thumbnail_url TEXT,
  activity_type TEXT NOT NULL, -- 'running', 'kicking', 'jumping'
  status TEXT NOT NULL DEFAULT 'uploaded', -- 'uploaded', 'processing', 'completed', 'failed'
  file_size_bytes INTEGER,
  duration_seconds INTEGER,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE analysis_results (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  video_id INTEGER NOT NULL,
  user_id INTEGER NOT NULL,
  overall_score INTEGER, -- 0-100
  movement_quality_score INTEGER, -- 0-100
  technique_score INTEGER, -- 0-100
  consistency_score INTEGER, -- 0-100
  pose_data TEXT, -- JSON string of pose detection results
  improvement_tips TEXT, -- JSON array of tips
  detected_errors TEXT, -- JSON array of errors found
  benchmark_comparison TEXT, -- JSON comparison with professional benchmarks
  processing_time_ms INTEGER,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE coach_feedback (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  analysis_result_id INTEGER NOT NULL,
  coach_id INTEGER NOT NULL,
  athlete_id INTEGER NOT NULL,
  feedback_text TEXT NOT NULL,
  recommendations TEXT, -- JSON array of recommendations
  focus_areas TEXT, -- JSON array of areas to focus on
  is_read BOOLEAN DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE coach_groups (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  coach_id INTEGER NOT NULL,
  name TEXT NOT NULL,
  description TEXT,
  invite_code TEXT UNIQUE,
  is_active BOOLEAN DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE group_memberships (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  group_id INTEGER NOT NULL,
  athlete_id INTEGER NOT NULL,
  joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  is_active BOOLEAN DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_users_mocha_user_id ON users(mocha_user_id);
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_videos_user_id ON videos(user_id);
CREATE INDEX idx_videos_status ON videos(status);
CREATE INDEX idx_analysis_results_video_id ON analysis_results(video_id);
CREATE INDEX idx_analysis_results_user_id ON analysis_results(user_id);
CREATE INDEX idx_coach_feedback_athlete_id ON coach_feedback(athlete_id);
CREATE INDEX idx_coach_feedback_coach_id ON coach_feedback(coach_id);
CREATE INDEX idx_group_memberships_athlete_id ON group_memberships(athlete_id);
CREATE INDEX idx_group_memberships_group_id ON group_memberships(group_id);
