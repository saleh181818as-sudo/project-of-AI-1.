
DROP INDEX idx_group_memberships_group_id;
DROP INDEX idx_group_memberships_athlete_id;
DROP INDEX idx_coach_feedback_coach_id;
DROP INDEX idx_coach_feedback_athlete_id;
DROP INDEX idx_analysis_results_user_id;
DROP INDEX idx_analysis_results_video_id;
DROP INDEX idx_videos_status;
DROP INDEX idx_videos_user_id;
DROP INDEX idx_users_email;
DROP INDEX idx_users_mocha_user_id;
DROP TABLE group_memberships;
DROP TABLE coach_groups;
DROP TABLE coach_feedback;
DROP TABLE analysis_results;
DROP TABLE videos;
DROP TABLE users;
