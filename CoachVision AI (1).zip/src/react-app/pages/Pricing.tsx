import { useAuth } from '@getmocha/users-service/react';
import { useNavigate } from 'react-router';
import Layout from '@/react-app/components/Layout';
import { Check, Star, Zap, Crown } from 'lucide-react';

export default function Pricing() {
  const { user, redirectToLogin } = useAuth();
  const navigate = useNavigate();

  const handleGetStarted = () => {
    if (user) {
      navigate('/dashboard');
    } else {
      redirectToLogin();
    }
  };

  return (
    <Layout>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        {/* Header */}
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-blue-600 to-green-600 bg-clip-text text-transparent mb-6">
            Choose Your Plan
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Start free and upgrade when you're ready to unlock the full potential of AI-powered sports analysis.
          </p>
        </div>

        {/* Pricing Cards */}
        <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto mb-16">
          {/* Free Plan */}
          <div className="bg-white rounded-2xl shadow-lg border-2 border-gray-200 p-8 relative">
            <div className="text-center">
              <Zap className="w-12 h-12 text-blue-600 mx-auto mb-4" />
              <h3 className="text-2xl font-bold text-gray-900 mb-2">Free</h3>
              <div className="text-5xl font-bold text-gray-900 mb-2">
                $0
                <span className="text-lg text-gray-500 font-normal">/month</span>
              </div>
              <p className="text-gray-600 mb-8">Perfect for getting started</p>
            </div>

            <ul className="space-y-4 mb-8">
              <li className="flex items-center space-x-3">
                <Check className="w-5 h-5 text-green-500 flex-shrink-0" />
                <span className="text-gray-700">3 video analyses per week</span>
              </li>
              <li className="flex items-center space-x-3">
                <Check className="w-5 h-5 text-green-500 flex-shrink-0" />
                <span className="text-gray-700">Basic movement analysis</span>
              </li>
              <li className="flex items-center space-x-3">
                <Check className="w-5 h-5 text-green-500 flex-shrink-0" />
                <span className="text-gray-700">Performance scores & feedback</span>
              </li>
              <li className="flex items-center space-x-3">
                <Check className="w-5 h-5 text-green-500 flex-shrink-0" />
                <span className="text-gray-700">Basic progress tracking</span>
              </li>
              <li className="flex items-center space-x-3">
                <Check className="w-5 h-5 text-green-500 flex-shrink-0" />
                <span className="text-gray-700">Email support</span>
              </li>
            </ul>

            <button
              onClick={handleGetStarted}
              className="w-full py-3 px-6 border-2 border-blue-600 text-blue-600 rounded-xl font-semibold hover:bg-blue-50 transition-colors"
            >
              Get Started Free
            </button>
          </div>

          {/* Pro Plan */}
          <div className="bg-gradient-to-br from-blue-600 to-green-600 rounded-2xl shadow-2xl text-white p-8 relative transform scale-105">
            <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
              <div className="bg-yellow-400 text-yellow-900 px-4 py-2 rounded-full text-sm font-bold flex items-center space-x-1">
                <Star className="w-4 h-4" />
                <span>Most Popular</span>
              </div>
            </div>

            <div className="text-center">
              <Crown className="w-12 h-12 text-yellow-300 mx-auto mb-4" />
              <h3 className="text-2xl font-bold mb-2">Pro</h3>
              <div className="text-5xl font-bold mb-2">
                $19
                <span className="text-lg opacity-80 font-normal">/month</span>
              </div>
              <p className="opacity-90 mb-8">For serious athletes and coaches</p>
            </div>

            <ul className="space-y-4 mb-8">
              <li className="flex items-center space-x-3">
                <Check className="w-5 h-5 text-green-300 flex-shrink-0" />
                <span>Unlimited video analyses</span>
              </li>
              <li className="flex items-center space-x-3">
                <Check className="w-5 h-5 text-green-300 flex-shrink-0" />
                <span>Advanced AI insights & recommendations</span>
              </li>
              <li className="flex items-center space-x-3">
                <Check className="w-5 h-5 text-green-300 flex-shrink-0" />
                <span>Detailed biomechanical analysis</span>
              </li>
              <li className="flex items-center space-x-3">
                <Check className="w-5 h-5 text-green-300 flex-shrink-0" />
                <span>Coach collaboration tools</span>
              </li>
              <li className="flex items-center space-x-3">
                <Check className="w-5 h-5 text-green-300 flex-shrink-0" />
                <span>Advanced progress analytics</span>
              </li>
              <li className="flex items-center space-x-3">
                <Check className="w-5 h-5 text-green-300 flex-shrink-0" />
                <span>Team management features</span>
              </li>
              <li className="flex items-center space-x-3">
                <Check className="w-5 h-5 text-green-300 flex-shrink-0" />
                <span>Priority support</span>
              </li>
              <li className="flex items-center space-x-3">
                <Check className="w-5 h-5 text-green-300 flex-shrink-0" />
                <span>Export data & reports</span>
              </li>
            </ul>

            <button
              onClick={handleGetStarted}
              className="w-full py-3 px-6 bg-white text-blue-600 rounded-xl font-semibold hover:bg-gray-50 transition-colors"
            >
              Upgrade to Pro
            </button>
          </div>
        </div>

        {/* Feature Comparison */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
          <div className="bg-gray-50 px-6 py-4">
            <h3 className="text-lg font-semibold text-gray-900">Feature Comparison</h3>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-200">
                  <th className="text-left py-4 px-6 font-medium text-gray-900">Features</th>
                  <th className="text-center py-4 px-6 font-medium text-gray-900">Free</th>
                  <th className="text-center py-4 px-6 font-medium text-gray-900">Pro</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                <tr>
                  <td className="py-4 px-6 text-gray-700">Video analyses per week</td>
                  <td className="py-4 px-6 text-center">3</td>
                  <td className="py-4 px-6 text-center text-green-600 font-semibold">Unlimited</td>
                </tr>
                <tr>
                  <td className="py-4 px-6 text-gray-700">Movement analysis</td>
                  <td className="py-4 px-6 text-center"><Check className="w-5 h-5 text-green-500 mx-auto" /></td>
                  <td className="py-4 px-6 text-center"><Check className="w-5 h-5 text-green-500 mx-auto" /></td>
                </tr>
                <tr>
                  <td className="py-4 px-6 text-gray-700">Performance scores</td>
                  <td className="py-4 px-6 text-center"><Check className="w-5 h-5 text-green-500 mx-auto" /></td>
                  <td className="py-4 px-6 text-center"><Check className="w-5 h-5 text-green-500 mx-auto" /></td>
                </tr>
                <tr>
                  <td className="py-4 px-6 text-gray-700">Advanced AI insights</td>
                  <td className="py-4 px-6 text-center">-</td>
                  <td className="py-4 px-6 text-center"><Check className="w-5 h-5 text-green-500 mx-auto" /></td>
                </tr>
                <tr>
                  <td className="py-4 px-6 text-gray-700">Coach collaboration</td>
                  <td className="py-4 px-6 text-center">-</td>
                  <td className="py-4 px-6 text-center"><Check className="w-5 h-5 text-green-500 mx-auto" /></td>
                </tr>
                <tr>
                  <td className="py-4 px-6 text-gray-700">Team management</td>
                  <td className="py-4 px-6 text-center">-</td>
                  <td className="py-4 px-6 text-center"><Check className="w-5 h-5 text-green-500 mx-auto" /></td>
                </tr>
                <tr>
                  <td className="py-4 px-6 text-gray-700">Export & reports</td>
                  <td className="py-4 px-6 text-center">-</td>
                  <td className="py-4 px-6 text-center"><Check className="w-5 h-5 text-green-500 mx-auto" /></td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        {/* FAQ Section */}
        <div className="mt-20 text-center">
          <h2 className="text-3xl font-bold text-gray-900 mb-8">Frequently Asked Questions</h2>
          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto text-left">
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
              <h3 className="font-semibold text-gray-900 mb-2">Can I change plans anytime?</h3>
              <p className="text-gray-600">Yes, you can upgrade or downgrade your plan at any time. Changes take effect immediately.</p>
            </div>
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
              <h3 className="font-semibold text-gray-900 mb-2">What sports are supported?</h3>
              <p className="text-gray-600">Currently we support running, jumping, and kicking analysis. More sports coming soon!</p>
            </div>
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
              <h3 className="font-semibold text-gray-900 mb-2">How accurate is the AI analysis?</h3>
              <p className="text-gray-600">Our AI achieves professional-grade accuracy and is continuously improving with more data.</p>
            </div>
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
              <h3 className="font-semibold text-gray-900 mb-2">Is there a refund policy?</h3>
              <p className="text-gray-600">We offer a 30-day money-back guarantee for Pro subscriptions. No questions asked.</p>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}
