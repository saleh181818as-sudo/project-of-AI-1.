import { useState } from 'react';
import { useNavigate } from 'react-router';
import Layout from '@/react-app/components/Layout';
import { Play, Pause, RotateCcw, TrendingUp, Target, Award } from 'lucide-react';

export default function Demo() {
  const navigate = useNavigate();
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0);

  const handlePlayPause = () => {
    setIsPlaying(!isPlaying);
    if (!isPlaying) {
      // Simulate video progress
      const interval = setInterval(() => {
        setProgress(prev => {
          if (prev >= 100) {
            setIsPlaying(false);
            clearInterval(interval);
            return 100;
          }
          return prev + 2;
        });
      }, 100);
    }
  };

  const handleReset = () => {
    setProgress(0);
    setIsPlaying(false);
  };

  return (
    <Layout>
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Try CoachVision AI Demo</h1>
          <p className="text-gray-600">
            Experience our AI-powered movement analysis with this interactive demonstration
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Video Player */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Sample Running Analysis</h2>
            
            <div className="relative bg-gray-900 rounded-lg overflow-hidden mb-4" style={{ aspectRatio: '16/9' }}>
              <div className="absolute inset-0 bg-gradient-to-br from-blue-600/20 to-green-600/20 flex items-center justify-center">
                <div className="text-center text-white">
                  <div className="w-20 h-20 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Target className="w-10 h-10" />
                  </div>
                  <p className="text-lg font-medium">AI Analysis in Progress</p>
                  <p className="text-sm opacity-80">Analyzing movement patterns...</p>
                </div>
              </div>
              
              {/* Progress overlay */}
              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/50 to-transparent p-4">
                <div className="flex items-center space-x-4">
                  <button
                    onClick={handlePlayPause}
                    className="w-10 h-10 bg-white rounded-full flex items-center justify-center hover:bg-gray-100 transition-colors"
                  >
                    {isPlaying ? <Pause className="w-5 h-5 text-gray-900" /> : <Play className="w-5 h-5 text-gray-900 ml-0.5" />}
                  </button>
                  
                  <div className="flex-1">
                    <div className="bg-gray-600 rounded-full h-1">
                      <div 
                        className="bg-white rounded-full h-1 transition-all duration-100"
                        style={{ width: `${progress}%` }}
                      />
                    </div>
                  </div>
                  
                  <button
                    onClick={handleReset}
                    className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center hover:bg-white/30 transition-colors"
                  >
                    <RotateCcw className="w-4 h-4 text-white" />
                  </button>
                </div>
              </div>
            </div>

            <div className="text-sm text-gray-600">
              <p><strong>Activity:</strong> Sprint Training</p>
              <p><strong>Duration:</strong> 0:15s</p>
              <p><strong>Analysis Status:</strong> {progress === 100 ? 'Complete' : isPlaying ? 'Processing...' : 'Ready'}</p>
            </div>
          </div>

          {/* Results Panel */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-6">Live Analysis Results</h2>
            
            <div className="space-y-6">
              {/* Overall Score */}
              <div className="text-center p-6 bg-gradient-to-br from-blue-50 to-green-50 rounded-lg">
                <div className="w-16 h-16 bg-gradient-to-br from-blue-600 to-green-600 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Award className="w-8 h-8 text-white" />
                </div>
                <div className="text-3xl font-bold text-gray-900 mb-1">
                  {progress > 50 ? '87' : '--'}
                </div>
                <div className="text-sm text-gray-600">Overall Score</div>
              </div>

              {/* Performance Metrics */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-gray-700">Movement Quality</span>
                  <div className="flex items-center space-x-2">
                    <div className="w-24 bg-gray-200 rounded-full h-2">
                      <div 
                        className="bg-gradient-to-r from-blue-500 to-green-500 h-2 rounded-full transition-all duration-1000"
                        style={{ width: progress > 30 ? '85%' : '0%' }}
                      />
                    </div>
                    <span className="text-sm font-medium text-gray-900 w-8">
                      {progress > 30 ? '85' : '--'}
                    </span>
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-gray-700">Technique Score</span>
                  <div className="flex items-center space-x-2">
                    <div className="w-24 bg-gray-200 rounded-full h-2">
                      <div 
                        className="bg-gradient-to-r from-green-500 to-blue-500 h-2 rounded-full transition-all duration-1000 delay-200"
                        style={{ width: progress > 50 ? '91%' : '0%' }}
                      />
                    </div>
                    <span className="text-sm font-medium text-gray-900 w-8">
                      {progress > 50 ? '91' : '--'}
                    </span>
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-gray-700">Consistency</span>
                  <div className="flex items-center space-x-2">
                    <div className="w-24 bg-gray-200 rounded-full h-2">
                      <div 
                        className="bg-gradient-to-r from-purple-500 to-pink-500 h-2 rounded-full transition-all duration-1000 delay-400"
                        style={{ width: progress > 70 ? '78%' : '0%' }}
                      />
                    </div>
                    <span className="text-sm font-medium text-gray-900 w-8">
                      {progress > 70 ? '78' : '--'}
                    </span>
                  </div>
                </div>
              </div>

              {/* Key Insights */}
              {progress > 80 && (
                <div className="mt-6 p-4 bg-blue-50 rounded-lg border border-blue-100">
                  <h3 className="font-semibold text-blue-900 mb-2 flex items-center">
                    <TrendingUp className="w-4 h-4 mr-2" />
                    Key Insights
                  </h3>
                  <ul className="text-sm text-blue-800 space-y-1">
                    <li>• Excellent stride length consistency</li>
                    <li>• Minor heel strike adjustment needed</li>
                    <li>• Strong core stability detected</li>
                  </ul>
                </div>
              )}
            </div>
          </div>
        </div>

        <div className="mt-8 text-center">
          <p className="text-gray-600 mb-6">
            This is just a preview! Sign up to analyze your own videos and get personalized coaching recommendations.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <button
              onClick={() => navigate('/pricing')}
              className="bg-gradient-to-r from-blue-600 to-green-600 text-white px-8 py-3 rounded-lg font-semibold hover:shadow-lg transform hover:-translate-y-0.5 transition-all duration-200"
            >
              Get Started Free
            </button>
            <button
              onClick={() => navigate('/')}
              className="text-gray-600 hover:text-blue-600 transition-colors"
            >
              Learn More
            </button>
          </div>
        </div>
      </div>
    </Layout>
  );
}
