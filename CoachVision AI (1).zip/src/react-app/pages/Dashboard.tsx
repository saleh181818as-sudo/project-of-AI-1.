import { useAuth } from '@getmocha/users-service/react';
import { useNavigate } from 'react-router';
import { useEffect, useState } from 'react';
import Layout from '@/react-app/components/Layout';
import { Upload, Play, TrendingUp, Target, Plus, Clock, CheckCircle, AlertCircle, Zap, Award, BarChart3 } from 'lucide-react';
import { Video } from '@/shared/types';
import { useProfile } from '@/react-app/hooks/useProfile';

interface VideoWithAnalysis extends Video {
  overall_score?: number;
  analysis_date?: string;
}

export default function Dashboard() {
  const { user, isPending } = useAuth();
  const { profile, loading: profileLoading, error: profileError } = useProfile();
  const navigate = useNavigate();
  const [videos, setVideos] = useState<VideoWithAnalysis[]>([]);
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({
    totalVideos: 0,
    avgScore: 0,
    analysesThisWeek: 0,
    weeklyLimit: 3
  });

  useEffect(() => {
    if (!isPending && !user) {
      navigate('/');
      return;
    }

    if (user && profile) {
      fetchVideos();
    } else if (user && !profileLoading && profileError) {
      // If there's an error loading profile, still allow basic dashboard functionality
      setLoading(false);
    }
  }, [user, isPending, profile, profileLoading, profileError, navigate]);

  const fetchVideos = async () => {
    try {
      const response = await fetch('/api/videos');
      const data = await response.json();
      
      if (response.ok) {
        setVideos(data.videos);
        
        // Calculate stats
        const totalVideos = data.videos.length;
        const completedVideos = data.videos.filter((v: VideoWithAnalysis) => v.overall_score !== null);
        const avgScore = completedVideos.length > 0 
          ? completedVideos.reduce((sum: number, v: VideoWithAnalysis) => sum + (v.overall_score || 0), 0) / completedVideos.length
          : 0;

        setStats({
          totalVideos,
          avgScore: Math.round(avgScore),
          analysesThisWeek: profile?.user?.analyses_used_this_week || 0,
          weeklyLimit: profile?.user?.subscription_plan === 'pro' ? Infinity : 3
        });
      }
    } catch (error) {
      console.error('Failed to fetch videos:', error);
    } finally {
      setLoading(false);
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="w-5 h-5 text-green-500" />;
      case 'processing':
        return <Clock className="w-5 h-5 text-blue-500 animate-spin" />;
      case 'failed':
        return <AlertCircle className="w-5 h-5 text-red-500" />;
      default:
        return <Clock className="w-5 h-5 text-gray-400" />;
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'completed':
        return 'Analysis Complete';
      case 'processing':
        return 'Analyzing...';
      case 'failed':
        return 'Analysis Failed';
      default:
        return 'Uploaded';
    }
  };

  const getScoreColor = (score: number) => {
    if (score >= 90) return 'text-green-600';
    if (score >= 80) return 'text-blue-600';
    if (score >= 70) return 'text-yellow-600';
    return 'text-red-600';
  };

  if (isPending || (profileLoading && !profileError)) {
    return (
      <Layout>
        <div className="flex items-center justify-center h-96">
          <div className="relative">
            <div className="w-16 h-16 bg-gradient-to-r from-blue-600 to-purple-600 rounded-full animate-spin">
              <div className="w-4 h-4 bg-white rounded-full m-2"></div>
            </div>
            <div className="absolute inset-0 bg-gradient-to-r from-blue-600 to-purple-600 rounded-full blur animate-pulse opacity-50"></div>
          </div>
        </div>
      </Layout>
    );
  }

  if (profileError) {
    return (
      <Layout>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="card-gradient p-8 text-center">
            <AlertCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-gray-900 mb-2">Unable to Load Profile</h2>
            <p className="text-gray-600 mb-6">There was an error loading your profile data: {profileError}</p>
            <button
              onClick={() => window.location.reload()}
              className="bg-gradient-to-r from-blue-600 to-purple-600 text-white px-6 py-3 rounded-xl hover:shadow-xl transition-all duration-300 font-semibold"
            >
              Reload Page
            </button>
          </div>
        </div>
      </Layout>
    );
  }

  if (loading) {
    return (
      <Layout>
        <div className="flex items-center justify-center h-96">
          <div className="relative">
            <div className="w-16 h-16 bg-gradient-to-r from-blue-600 to-purple-600 rounded-full animate-spin">
              <div className="w-4 h-4 bg-white rounded-full m-2"></div>
            </div>
            <div className="absolute inset-0 bg-gradient-to-r from-blue-600 to-purple-600 rounded-full blur animate-pulse opacity-50"></div>
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Enhanced Header */}
        <div className="mb-10 relative">
          <div className="absolute -top-4 -left-4 w-20 h-20 bg-gradient-to-br from-blue-400/20 to-purple-400/20 rounded-full blur-xl"></div>
          <h1 className="text-4xl font-black text-gradient-animated mb-3 relative z-10">
            Welcome back, {profile?.mochaUser?.google_user_data?.given_name || 'Champion'}! 🏆
          </h1>
          <p className="text-gray-600 text-lg relative z-10">
            Track your progress and unlock your athletic potential with AI-powered insights.
          </p>
        </div>

        {/* Enhanced Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-10">
          <div className="card-gradient p-6 hover-lift relative overflow-hidden group">
            <div className="absolute top-0 right-0 w-20 h-20 bg-gradient-to-br from-blue-400/10 to-blue-600/10 rounded-full -mr-10 -mt-10"></div>
            <div className="flex items-center justify-between relative z-10">
              <div>
                <p className="text-sm font-semibold text-gray-600 uppercase tracking-wide">Total Videos</p>
                <p className="text-4xl font-black text-gray-900 group-hover:text-blue-600 transition-colors duration-300">{stats.totalVideos}</p>
              </div>
              <div className="w-14 h-14 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl flex items-center justify-center shadow-lg group-hover:shadow-glow transition-all duration-300">
                <Play className="w-7 h-7 text-white group-hover:scale-110 transition-transform duration-300" />
              </div>
            </div>
          </div>

          <div className="card-gradient p-6 hover-lift relative overflow-hidden group">
            <div className="absolute top-0 right-0 w-20 h-20 bg-gradient-to-br from-green-400/10 to-green-600/10 rounded-full -mr-10 -mt-10"></div>
            <div className="flex items-center justify-between relative z-10">
              <div>
                <p className="text-sm font-semibold text-gray-600 uppercase tracking-wide">Avg Score</p>
                <p className={`text-4xl font-black transition-colors duration-300 ${getScoreColor(stats.avgScore)}`}>
                  {stats.avgScore}%
                </p>
              </div>
              <div className="w-14 h-14 bg-gradient-to-br from-green-500 to-green-600 rounded-xl flex items-center justify-center shadow-lg group-hover:shadow-glow-green transition-all duration-300">
                <TrendingUp className="w-7 h-7 text-white group-hover:scale-110 transition-transform duration-300" />
              </div>
            </div>
          </div>

          <div className="card-gradient p-6 hover-lift relative overflow-hidden group">
            <div className="absolute top-0 right-0 w-20 h-20 bg-gradient-to-br from-purple-400/10 to-purple-600/10 rounded-full -mr-10 -mt-10"></div>
            <div className="flex items-center justify-between relative z-10">
              <div>
                <p className="text-sm font-semibold text-gray-600 uppercase tracking-wide">This Week</p>
                <p className="text-4xl font-black text-gray-900 group-hover:text-purple-600 transition-colors duration-300">
                  {stats.analysesThisWeek}
                  {stats.weeklyLimit !== Infinity && (
                    <span className="text-lg text-gray-500 font-normal">/{stats.weeklyLimit}</span>
                  )}
                </p>
              </div>
              <div className="w-14 h-14 bg-gradient-to-br from-purple-500 to-purple-600 rounded-xl flex items-center justify-center shadow-lg group-hover:shadow-glow transition-all duration-300">
                <Target className="w-7 h-7 text-white group-hover:scale-110 transition-transform duration-300" />
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-br from-blue-600 via-purple-600 to-green-600 p-6 rounded-xl text-white hover-lift shadow-xl-colored relative overflow-hidden group">
            <div className="absolute inset-0 bg-white/10 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            <div className="flex items-center justify-between relative z-10">
              <div>
                <p className="text-sm opacity-90 font-semibold uppercase tracking-wide">Plan</p>
                <p className="text-3xl font-black capitalize">{profile?.user?.subscription_plan}</p>
              </div>
              <button
                onClick={() => navigate('/pricing')}
                className="bg-white/20 hover:bg-white/30 p-3 rounded-xl transition-all duration-300 group-hover:scale-110"
              >
                <Plus className="w-6 h-6" />
              </button>
            </div>
          </div>
        </div>

        {/* Enhanced Quick Actions */}
        <div className="card-gradient p-8 mb-10 hover-lift">
          <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center">
            <Zap className="w-6 h-6 text-yellow-500 mr-2" />
            Quick Actions
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <button
              onClick={() => navigate('/upload')}
              className="group flex items-center space-x-4 p-6 rounded-xl border-2 border-dashed border-blue-300 hover:border-blue-400 hover:bg-blue-50 transition-all duration-300 hover-lift"
            >
              <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl flex items-center justify-center shadow-lg group-hover:shadow-glow transition-all duration-300">
                <Upload className="w-6 h-6 text-white group-hover:scale-110 transition-transform duration-300" />
              </div>
              <div className="text-left">
                <div className="font-bold text-gray-900 text-lg">Upload Video</div>
                <div className="text-gray-600">Analyze new performance</div>
              </div>
            </button>

            <button
              onClick={() => navigate('/results')}
              className="group flex items-center space-x-4 p-6 rounded-xl border border-gray-200 hover:bg-gray-50 transition-all duration-300 hover-lift"
            >
              <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-green-600 rounded-xl flex items-center justify-center shadow-lg group-hover:shadow-glow-green transition-all duration-300">
                <BarChart3 className="w-6 h-6 text-white group-hover:scale-110 transition-transform duration-300" />
              </div>
              <div className="text-left">
                <div className="font-bold text-gray-900 text-lg">View Results</div>
                <div className="text-gray-600">Check analysis history</div>
              </div>
            </button>

            {profile?.user?.role === 'coach' && (
              <button
                onClick={() => navigate('/coach')}
                className="group flex items-center space-x-4 p-6 rounded-xl border border-gray-200 hover:bg-gray-50 transition-all duration-300 hover-lift"
              >
                <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-purple-600 rounded-xl flex items-center justify-center shadow-lg group-hover:shadow-glow transition-all duration-300">
                  <Target className="w-6 h-6 text-white group-hover:scale-110 transition-transform duration-300" />
                </div>
                <div className="text-left">
                  <div className="font-bold text-gray-900 text-lg">Coach Panel</div>
                  <div className="text-gray-600">Manage athletes</div>
                </div>
              </button>
            )}
          </div>
        </div>

        {/* Enhanced Recent Videos */}
        <div className="card-gradient p-8 hover-lift">
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-2xl font-bold text-gray-900 flex items-center">
              <Award className="w-6 h-6 text-blue-500 mr-2" />
              Recent Videos
            </h2>
            <button
              onClick={() => navigate('/results')}
              className="text-blue-600 hover:text-blue-700 font-semibold hover-lift transition-all duration-300"
            >
              View all →
            </button>
          </div>

          {videos.length === 0 ? (
            <div className="text-center py-16">
              <div className="w-24 h-24 bg-gradient-to-br from-blue-100 to-purple-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <Upload className="w-12 h-12 text-gray-400" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-3">Ready to begin your journey?</h3>
              <p className="text-gray-600 mb-8 max-w-md mx-auto">Upload your first training video and let our AI coach analyze your performance in seconds.</p>
              <button
                onClick={() => navigate('/upload')}
                className="bg-gradient-to-r from-blue-600 to-purple-600 text-white px-8 py-4 rounded-xl hover:shadow-xl transition-all duration-300 font-semibold hover-lift btn-glow"
              >
                Upload First Video
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              {videos.slice(0, 5).map((video) => (
                <div
                  key={video.id}
                  className="group flex items-center justify-between p-6 border border-gray-200 rounded-xl hover:bg-gradient-to-r hover:from-blue-50 hover:to-purple-50 transition-all duration-300 cursor-pointer hover-lift"
                  onClick={() => {
                    if (video.status === 'completed' && video.overall_score !== null) {
                      navigate(`/results/${video.id}`);
                    }
                  }}
                >
                  <div className="flex items-center space-x-6">
                    <div className="w-16 h-16 bg-gradient-to-br from-blue-100 to-purple-100 rounded-xl flex items-center justify-center shadow-lg group-hover:shadow-glow transition-all duration-300">
                      <Play className="w-8 h-8 text-blue-600 group-hover:scale-110 transition-transform duration-300" />
                    </div>
                    <div>
                      <h3 className="font-bold text-gray-900 text-lg group-hover:text-blue-600 transition-colors duration-300">{video.title}</h3>
                      <p className="text-gray-600 capitalize font-medium">{video.activity_type}</p>
                    </div>
                  </div>

                  <div className="flex items-center space-x-8">
                    {video.overall_score !== null && video.overall_score !== undefined && (
                      <div className="text-right">
                        <div className={`text-3xl font-black transition-colors duration-300 ${getScoreColor(video.overall_score)}`}>
                          {video.overall_score}%
                        </div>
                        <div className="text-sm text-gray-600 font-medium">Performance Score</div>
                      </div>
                    )}
                    
                    <div className="flex items-center space-x-3">
                      {getStatusIcon(video.status)}
                      <span className="text-sm text-gray-600 font-medium">{getStatusText(video.status)}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </Layout>
  );
}
