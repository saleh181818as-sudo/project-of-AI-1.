import { useAuth } from '@getmocha/users-service/react';
import { useNavigate } from 'react-router';
import { useEffect, useState } from 'react';
import Layout from '@/react-app/components/Layout';
import { Play, TrendingUp, Clock, CheckCircle, AlertCircle, Filter } from 'lucide-react';

interface VideoWithAnalysis {
  id: number;
  title: string;
  activity_type: string;
  status: string;
  overall_score?: number;
  analysis_date?: string;
  created_at: string;
}

export default function Results() {
  const { user, isPending } = useAuth();
  const navigate = useNavigate();
  const [videos, setVideos] = useState<VideoWithAnalysis[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'all' | 'completed' | 'processing'>('all');

  useEffect(() => {
    if (!isPending && !user) {
      navigate('/');
      return;
    }

    if (user) {
      fetchVideos();
    }
  }, [user, isPending, navigate]);

  const fetchVideos = async () => {
    try {
      const response = await fetch('/api/videos');
      const data = await response.json();
      
      if (response.ok) {
        setVideos(data.videos);
      }
    } catch (error) {
      console.error('Failed to fetch videos:', error);
    } finally {
      setLoading(false);
    }
  };

  const filteredVideos = videos.filter(video => {
    if (filter === 'completed') return video.status === 'completed';
    if (filter === 'processing') return video.status === 'processing';
    return true;
  });

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="w-5 h-5 text-green-500" />;
      case 'processing':
        return <Clock className="w-5 h-5 text-blue-500 animate-spin" />;
      case 'failed':
        return <AlertCircle className="w-5 h-5 text-red-500" />;
      default:
        return <Clock className="w-5 h-5 text-gray-400" />;
    }
  };

  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-green-600';
    if (score >= 60) return 'text-yellow-600';
    return 'text-red-600';
  };

  if (isPending || loading) {
    return (
      <Layout>
        <div className="flex items-center justify-center h-96">
          <div className="animate-spin">
            <TrendingUp className="w-12 h-12 text-blue-600" />
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Analysis Results</h1>
            <p className="text-gray-600">
              Review your performance analysis and track your progress over time.
            </p>
          </div>
          <button
            onClick={() => navigate('/upload')}
            className="bg-gradient-to-r from-blue-600 to-green-600 text-white px-6 py-3 rounded-lg hover:shadow-lg transition-shadow"
          >
            Upload New Video
          </button>
        </div>

        {/* Filters */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 mb-6">
          <div className="flex items-center space-x-4">
            <Filter className="w-5 h-5 text-gray-400" />
            <span className="text-sm font-medium text-gray-700">Filter by status:</span>
            <div className="flex space-x-2">
              {[
                { key: 'all', label: 'All Videos' },
                { key: 'completed', label: 'Completed' },
                { key: 'processing', label: 'Processing' },
              ].map((option) => (
                <button
                  key={option.key}
                  onClick={() => setFilter(option.key as typeof filter)}
                  className={`px-3 py-1 rounded-full text-sm font-medium transition-colors ${
                    filter === option.key
                      ? 'bg-blue-100 text-blue-700'
                      : 'text-gray-600 hover:bg-gray-100'
                  }`}
                >
                  {option.label}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Results Grid */}
        {filteredVideos.length === 0 ? (
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-12 text-center">
            <TrendingUp className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">
              {filter === 'all' ? 'No videos yet' : `No ${filter} videos`}
            </h3>
            <p className="text-gray-600 mb-4">
              {filter === 'all' 
                ? 'Upload your first training video to get started.'
                : `You don't have any ${filter} videos at the moment.`
              }
            </p>
            <button
              onClick={() => navigate('/upload')}
              className="bg-gradient-to-r from-blue-600 to-green-600 text-white px-6 py-2 rounded-lg hover:shadow-lg transition-shadow"
            >
              Upload Video
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredVideos.map((video) => (
              <div
                key={video.id}
                className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden hover:shadow-md transition-shadow cursor-pointer"
                onClick={() => {
                  if (video.status === 'completed' && video.overall_score !== null) {
                    navigate(`/results/${video.id}`);
                  }
                }}
              >
                {/* Video Thumbnail */}
                <div className="h-48 bg-gradient-to-br from-blue-100 to-green-100 flex items-center justify-center">
                  <Play className="w-16 h-16 text-blue-600" />
                </div>

                <div className="p-6">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-medium text-blue-600 bg-blue-100 px-2 py-1 rounded capitalize">
                      {video.activity_type}
                    </span>
                    <div className="flex items-center space-x-1">
                      {getStatusIcon(video.status)}
                    </div>
                  </div>

                  <h3 className="font-semibold text-gray-900 mb-2 line-clamp-2">
                    {video.title}
                  </h3>

                  {video.overall_score !== null && video.overall_score !== undefined ? (
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600">Overall Score</span>
                      <span className={`text-2xl font-bold ${getScoreColor(video.overall_score)}`}>
                        {video.overall_score}%
                      </span>
                    </div>
                  ) : (
                    <div className="text-sm text-gray-600">
                      {video.status === 'processing' ? 'Analysis in progress...' : 'Awaiting analysis'}
                    </div>
                  )}

                  <div className="mt-4 text-xs text-gray-500">
                    Uploaded {new Date(video.created_at).toLocaleDateString()}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </Layout>
  );
}
