import { useAuth } from '@getmocha/users-service/react';
import { useNavigate, useParams } from 'react-router';
import { useEffect, useState } from 'react';
import Layout from '@/react-app/components/Layout';
import { ArrowLeft, Play, Target, AlertTriangle, CheckCircle, Clock } from 'lucide-react';

interface AnalysisData {
  id: number;
  video_id: number;
  user_id: number;
  overall_score: number;
  movement_quality_score: number;
  technique_score: number;
  consistency_score: number;
  pose_data: string;
  improvement_tips: string;
  detected_errors: string;
  benchmark_comparison: string;
  processing_time_ms: number;
  created_at: string;
  title: string;
  activity_type: string;
  video_url: string;
}

export default function AnalysisResult() {
  const { user, isPending } = useAuth();
  const navigate = useNavigate();
  const { videoId } = useParams<{ videoId: string }>();
  const [analysis, setAnalysis] = useState<AnalysisData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!isPending && !user) {
      navigate('/');
      return;
    }

    if (user && videoId) {
      fetchAnalysis();
    }
  }, [user, isPending, navigate, videoId]);

  const fetchAnalysis = async () => {
    try {
      const response = await fetch(`/api/analysis/${videoId}`);
      const data = await response.json();
      
      if (response.ok) {
        setAnalysis(data.analysis);
      } else {
        console.error('Failed to fetch analysis:', data.error);
        navigate('/results');
      }
    } catch (error) {
      console.error('Failed to fetch analysis:', error);
      navigate('/results');
    } finally {
      setLoading(false);
    }
  };

  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-green-600 bg-green-100';
    if (score >= 60) return 'text-yellow-600 bg-yellow-100';
    return 'text-red-600 bg-red-100';
  };

  const getScoreIcon = (score: number) => {
    if (score >= 80) return <CheckCircle className="w-5 h-5" />;
    if (score >= 60) return <Clock className="w-5 h-5" />;
    return <AlertTriangle className="w-5 h-5" />;
  };

  if (isPending || loading) {
    return (
      <Layout>
        <div className="flex items-center justify-center h-96">
          <div className="animate-spin">
            <Target className="w-12 h-12 text-blue-600" />
          </div>
        </div>
      </Layout>
    );
  }

  if (!analysis) {
    return (
      <Layout>
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center">
            <h1 className="text-2xl font-bold text-gray-900 mb-4">Analysis Not Found</h1>
            <button
              onClick={() => navigate('/results')}
              className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700"
            >
              Back to Results
            </button>
          </div>
        </div>
      </Layout>
    );
  }

  const improvementTips = analysis.improvement_tips ? JSON.parse(analysis.improvement_tips) : [];
  const detectedErrors = analysis.detected_errors ? JSON.parse(analysis.detected_errors) : [];
  const benchmarkComparison = analysis.benchmark_comparison ? JSON.parse(analysis.benchmark_comparison) : null;

  return (
    <Layout>
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="flex items-center space-x-4 mb-8">
          <button
            onClick={() => navigate('/results')}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">{analysis.title}</h1>
            <p className="text-gray-600 capitalize">
              {analysis.activity_type} • Analyzed {new Date(analysis.created_at).toLocaleDateString()}
            </p>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Video Player */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
              <div className="h-96 bg-gradient-to-br from-blue-100 to-green-100 flex items-center justify-center">
                <Play className="w-24 h-24 text-blue-600" />
                <div className="absolute top-4 right-4 bg-black/50 text-white px-3 py-1 rounded-full text-sm">
                  Demo Video
                </div>
              </div>
            </div>

            {/* Performance Scores */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
              <h2 className="text-xl font-bold text-gray-900 mb-6">Performance Scores</h2>
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 rounded-lg bg-gray-50">
                    <span className="font-medium text-gray-700">Overall Score</span>
                    <div className={`flex items-center space-x-2 px-3 py-1 rounded-full ${getScoreColor(analysis.overall_score)}`}>
                      {getScoreIcon(analysis.overall_score)}
                      <span className="font-bold">{analysis.overall_score}%</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between p-4 rounded-lg bg-gray-50">
                    <span className="font-medium text-gray-700">Movement Quality</span>
                    <div className={`flex items-center space-x-2 px-3 py-1 rounded-full ${getScoreColor(analysis.movement_quality_score)}`}>
                      {getScoreIcon(analysis.movement_quality_score)}
                      <span className="font-bold">{analysis.movement_quality_score}%</span>
                    </div>
                  </div>
                </div>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 rounded-lg bg-gray-50">
                    <span className="font-medium text-gray-700">Technique</span>
                    <div className={`flex items-center space-x-2 px-3 py-1 rounded-full ${getScoreColor(analysis.technique_score)}`}>
                      {getScoreIcon(analysis.technique_score)}
                      <span className="font-bold">{analysis.technique_score}%</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between p-4 rounded-lg bg-gray-50">
                    <span className="font-medium text-gray-700">Consistency</span>
                    <div className={`flex items-center space-x-2 px-3 py-1 rounded-full ${getScoreColor(analysis.consistency_score)}`}>
                      {getScoreIcon(analysis.consistency_score)}
                      <span className="font-bold">{analysis.consistency_score}%</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Improvement Tips */}
            {improvementTips.length > 0 && (
              <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                <h2 className="text-xl font-bold text-gray-900 mb-6">Improvement Recommendations</h2>
                <div className="space-y-4">
                  {improvementTips.map((tip: any, index: number) => (
                    <div key={index} className="flex items-start space-x-3 p-4 bg-blue-50 rounded-lg">
                      <Target className="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" />
                      <div>
                        <div className="font-medium text-blue-900">{tip.category}</div>
                        <div className="text-blue-800 mt-1">{tip.message}</div>
                        <div className="text-sm text-blue-600 mt-2 capitalize">
                          Priority: {tip.severity} • Confidence: {Math.round(tip.confidence * 100)}%
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Detected Errors */}
            {detectedErrors.length > 0 && (
              <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                <h2 className="text-xl font-bold text-gray-900 mb-6">Detected Issues</h2>
                <div className="space-y-4">
                  {detectedErrors.map((error: any, index: number) => (
                    <div key={index} className="flex items-start space-x-3 p-4 bg-red-50 rounded-lg">
                      <AlertTriangle className="w-5 h-5 text-red-600 mt-0.5 flex-shrink-0" />
                      <div>
                        <div className="font-medium text-red-900">{error.type}</div>
                        <div className="text-red-800 mt-1">{error.description}</div>
                        <div className="text-sm text-red-600 mt-2 capitalize">
                          Severity: {error.severity} • Confidence: {Math.round(error.confidence * 100)}%
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Benchmark Comparison */}
            {benchmarkComparison && (
              <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                <h3 className="text-lg font-bold text-gray-900 mb-4">Benchmark Comparison</h3>
                <div className="space-y-4">
                  <div className="text-center p-4 bg-gradient-to-r from-blue-50 to-green-50 rounded-lg">
                    <div className="text-2xl font-bold text-gray-900">{benchmarkComparison.percentile}%</div>
                    <div className="text-sm text-gray-600">Percentile Rank</div>
                  </div>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Your Score</span>
                      <span className="font-semibold">{benchmarkComparison.user_score}%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Pro Average</span>
                      <span className="font-semibold">{benchmarkComparison.professional_average}%</span>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Analysis Stats */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
              <h3 className="text-lg font-bold text-gray-900 mb-4">Analysis Details</h3>
              <div className="space-y-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600">Processing Time</span>
                  <span className="font-medium">{(analysis.processing_time_ms / 1000).toFixed(2)}s</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Analysis Date</span>
                  <span className="font-medium">{new Date(analysis.created_at).toLocaleDateString()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Activity Type</span>
                  <span className="font-medium capitalize">{analysis.activity_type}</span>
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
              <h3 className="text-lg font-bold text-gray-900 mb-4">Actions</h3>
              <div className="space-y-3">
                <button
                  onClick={() => navigate('/upload')}
                  className="w-full bg-gradient-to-r from-blue-600 to-green-600 text-white py-2 px-4 rounded-lg hover:shadow-lg transition-shadow"
                >
                  Analyze New Video
                </button>
                <button
                  onClick={() => navigate('/results')}
                  className="w-full border border-gray-300 text-gray-700 py-2 px-4 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  View All Results
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}
