import { useAuth } from '@getmocha/users-service/react';
import { useNavigate } from 'react-router';
import { Play, Target, Sparkles, ArrowRight, Zap, Award, TrendingUp } from 'lucide-react';
import { useEffect, useState } from 'react';

export default function Home() {
  const { user, isPending, redirectToLogin } = useAuth();
  const navigate = useNavigate();
  const [mounted, setMounted] = useState(false);
  const [coachEmotion, setCoachEmotion] = useState('smile');
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    setMounted(true);
    setTimeout(() => setIsVisible(true), 100);
  }, []);

  useEffect(() => {
    if (mounted && !isPending && user) {
      navigate('/dashboard');
    }
  }, [user, isPending, navigate, mounted]);

  const handleStart = () => {
    setCoachEmotion('excited');
    setTimeout(() => setCoachEmotion('smile'), 1000);
    
    if (user) {
      navigate('/dashboard');
    } else {
      redirectToLogin();
    }
  };

  if (isPending || !mounted) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-green-50 flex items-center justify-center">
        <div className="animate-pulse-glow">
          <div className="w-20 h-20 bg-gradient-to-r from-blue-600 to-purple-600 rounded-full animate-spin">
            <div className="w-4 h-4 bg-white rounded-full m-2"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-green-50 overflow-hidden relative">
      {/* Animated Background Elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-gradient-to-br from-blue-400/20 to-purple-400/20 rounded-full blur-3xl animate-float"></div>
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-gradient-to-br from-green-400/20 to-blue-400/20 rounded-full blur-3xl animate-float delay-700"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-gradient-to-br from-purple-400/10 to-pink-400/10 rounded-full blur-3xl animate-pulse"></div>
      </div>

      {/* Navigation */}
      <nav className="relative z-20 glass rounded-b-2xl border-0 border-b border-white/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-20">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-600 via-purple-600 to-green-600 rounded-xl flex items-center justify-center shadow-lg animate-pulse-glow">
                <Target className="w-6 h-6 text-white" />
              </div>
              <span className="font-bold text-2xl text-gradient-animated">
                CoachVision AI
              </span>
            </div>
            <div className="flex items-center space-x-6">
              <button
                onClick={() => navigate('/demo')}
                className="text-gray-700 hover:text-blue-600 transition-all duration-300 font-medium hover-lift"
              >
                Try Demo
              </button>
              <button
                onClick={() => navigate('/pricing')}
                className="text-gray-700 hover:text-purple-600 transition-all duration-300 font-medium hover-lift"
              >
                Pricing
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center px-4">
        <div className={`max-w-6xl mx-auto text-center transition-all duration-1000 ${isVisible ? 'animate-slide-up' : 'opacity-0'}`}>
          
          {/* AI Coach Character - Enhanced */}
          <div className="mb-12 relative">
            <div className="relative mx-auto w-80 h-80 mb-8">
              {/* Outer Glow Ring */}
              <div className="absolute inset-0 bg-gradient-to-r from-blue-400 via-purple-400 to-green-400 rounded-full blur-xl opacity-30 animate-pulse"></div>
              
              {/* Coach Face Container */}
              <div className="relative w-80 h-80 rounded-full bg-gradient-to-br from-white/80 to-blue-50/80 glass border-4 border-white/30 shadow-2xl mx-auto transform hover:scale-105 transition-all duration-500 hover-glow">
                
                {/* Animated Background Pattern */}
                <div className="absolute inset-6 bg-gradient-to-br from-blue-100/50 to-purple-100/50 rounded-full animate-gradient-shift"></div>
                
                {/* Face Content */}
                <div className="absolute inset-8 bg-gradient-to-br from-blue-50/80 to-purple-50/80 rounded-full flex items-center justify-center relative overflow-hidden">
                  
                  {/* Eyes - Enhanced */}
                  <div className="absolute top-20 left-1/2 transform -translate-x-1/2 flex space-x-8">
                    <div className="relative">
                      <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-blue-700 rounded-full shadow-lg">
                        <div className="w-3 h-3 bg-white rounded-full absolute top-1 right-1 animate-pulse"></div>
                        <div className="w-1 h-1 bg-blue-200 rounded-full absolute top-2 right-2"></div>
                      </div>
                      <Sparkles className="absolute -top-2 -right-2 w-4 h-4 text-blue-400 animate-bounce-gentle" />
                    </div>
                    <div className="relative">
                      <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-blue-700 rounded-full shadow-lg">
                        <div className="w-3 h-3 bg-white rounded-full absolute top-1 right-1 animate-pulse"></div>
                        <div className="w-1 h-1 bg-blue-200 rounded-full absolute top-2 right-2"></div>
                      </div>
                      <Sparkles className="absolute -top-2 -left-2 w-4 h-4 text-purple-400 animate-bounce-gentle delay-300" />
                    </div>
                  </div>
                  
                  {/* Mouth with Emotions */}
                  <div className="absolute bottom-24 left-1/2 transform -translate-x-1/2">
                    {coachEmotion === 'smile' && (
                      <div className="w-16 h-8 border-b-4 border-gradient-to-r from-blue-600 to-purple-600 rounded-b-2xl shadow-lg animate-bounce-gentle"></div>
                    )}
                    {coachEmotion === 'excited' && (
                      <div className="w-12 h-12 bg-gradient-to-br from-yellow-400 to-orange-400 rounded-full animate-bounce shadow-lg">
                        <div className="w-8 h-8 bg-gradient-to-br from-yellow-300 to-orange-300 rounded-full m-2"></div>
                      </div>
                    )}
                  </div>
                  
                  {/* Floating AI Elements */}
                  <Zap className="absolute top-6 right-8 w-6 h-6 text-yellow-500 animate-bounce-gentle" />
                  <Award className="absolute bottom-6 left-8 w-6 h-6 text-green-500 animate-rotate-slow" />
                  <TrendingUp className="absolute top-1/2 left-4 w-5 h-5 text-purple-500 animate-pulse" />
                  <Target className="absolute top-1/2 right-4 w-5 h-5 text-blue-500 animate-spin" />
                </div>
              </div>
              
              {/* Floating Orbs Around Coach */}
              <div className="absolute -top-6 -left-6 w-12 h-12 bg-gradient-to-br from-blue-400 to-blue-500 rounded-full opacity-70 animate-float shadow-glow"></div>
              <div className="absolute -top-4 -right-8 w-8 h-8 bg-gradient-to-br from-purple-400 to-purple-500 rounded-full opacity-60 animate-float delay-300 shadow-glow"></div>
              <div className="absolute -bottom-6 -right-6 w-14 h-14 bg-gradient-to-br from-green-400 to-green-500 rounded-full opacity-60 animate-float delay-500 shadow-glow-green"></div>
              <div className="absolute -bottom-4 -left-8 w-10 h-10 bg-gradient-to-br from-yellow-400 to-yellow-500 rounded-full opacity-70 animate-float delay-700"></div>
            </div>
          </div>

          {/* Enhanced Text Section */}
          <div className="mb-16 space-y-6">
            <h1 className="text-5xl md:text-7xl font-black text-gradient-animated mb-8 leading-tight">
              Meet Your AI Coach
            </h1>
            <p className="text-2xl md:text-3xl text-gray-700 mb-6 max-w-4xl mx-auto leading-relaxed font-light">
              Transform your athletic performance with 
              <span className="text-gradient font-semibold"> cutting-edge AI analysis</span>
            </p>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto leading-relaxed">
              Upload your training videos and get instant, professional-grade analysis with personalized recommendations to unlock your true potential.
            </p>
          </div>

          {/* Enhanced CTA Button */}
          <div className="mb-20">
            <button
              onClick={handleStart}
              className="group relative bg-gradient-to-r from-blue-600 via-purple-600 to-green-600 text-white px-16 py-8 rounded-3xl text-3xl font-bold hover:shadow-2xl transform hover:-translate-y-3 transition-all duration-500 flex items-center space-x-6 mx-auto overflow-hidden btn-glow animate-pulse-glow"
            >
              <div className="absolute inset-0 bg-gradient-to-r from-blue-700 via-purple-700 to-green-700 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
              <Play className="w-10 h-10 relative z-10 group-hover:scale-110 transition-transform duration-300" />
              <span className="relative z-10">START ANALYSIS</span>
              <ArrowRight className="w-10 h-10 relative z-10 group-hover:translate-x-3 transition-transform duration-300" />
              
              {/* Shimmer Effect */}
              <div className="absolute inset-0 animate-shimmer opacity-0 group-hover:opacity-100"></div>
            </button>
            <p className="text-sm text-gray-500 mt-6 animate-fade-in-scale">
              {user ? '✨ Go to your dashboard' : '🚀 Sign up free • No credit card required • Start in 30 seconds'}
            </p>
          </div>

          {/* Enhanced Feature Cards */}
          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            <div className="card-glass p-8 hover-lift hover-scale group">
              <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-xl group-hover:shadow-glow transition-all duration-300">
                <Target className="w-8 h-8 text-white group-hover:scale-110 transition-transform duration-300" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Precision Analysis</h3>
              <p className="text-gray-600 leading-relaxed">Advanced AI detects micro-movements and technique flaws in running, jumping, and kicking with surgical precision</p>
            </div>

            <div className="card-glass p-8 hover-lift hover-scale group">
              <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-purple-600 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-xl group-hover:shadow-glow transition-all duration-300">
                <Sparkles className="w-8 h-8 text-white group-hover:scale-110 transition-transform duration-300" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Smart Insights</h3>
              <p className="text-gray-600 leading-relaxed">Get personalized coaching tips and improvement strategies tailored to your unique movement patterns</p>
            </div>

            <div className="card-glass p-8 hover-lift hover-scale group">
              <div className="w-16 h-16 bg-gradient-to-br from-green-500 to-green-600 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-xl group-hover:shadow-glow transition-all duration-300">
                <Zap className="w-8 h-8 text-white group-hover:scale-110 transition-transform duration-300" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">Instant Results</h3>
              <p className="text-gray-600 leading-relaxed">Upload your video and receive comprehensive analysis with actionable insights in under 30 seconds</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
