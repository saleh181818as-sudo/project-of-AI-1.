import { useAuth } from '@getmocha/users-service/react';
import { useNavigate, useLocation } from 'react-router';
import { Target, Home, Upload, BarChart3, Users, CreditCard, LogOut, Menu, X } from 'lucide-react';
import { useState } from 'react';
import { useProfile } from '@/react-app/hooks/useProfile';

interface LayoutProps {
  children: React.ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  const { logout } = useAuth();
  const { profile } = useProfile();
  const navigate = useNavigate();
  const location = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const handleLogout = async () => {
    await logout();
    navigate('/');
  };

  const navigation = [
    { name: 'Dashboard', href: '/dashboard', icon: Home },
    { name: 'Upload', href: '/upload', icon: Upload },
    { name: 'Results', href: '/results', icon: BarChart3 },
    ...(profile?.user?.role === 'coach' ? [{ name: 'Coach Panel', href: '/coach', icon: Users }] : []),
    { name: 'Pricing', href: '/pricing', icon: CreditCard },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-green-50 relative">
      {/* Background Elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-gradient-to-br from-blue-400/10 to-purple-400/10 rounded-full blur-3xl animate-float"></div>
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-gradient-to-br from-green-400/10 to-blue-400/10 rounded-full blur-3xl animate-float delay-700"></div>
      </div>

      {/* Enhanced Navigation */}
      <nav className="relative z-20 glass rounded-b-2xl border-0 border-b border-white/20 shadow-xl">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-20">
            {/* Logo */}
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-gradient-to-br from-blue-600 via-purple-600 to-green-600 rounded-xl flex items-center justify-center shadow-lg animate-pulse-glow hover-scale">
                <Target className="w-7 h-7 text-white" />
              </div>
              <span className="font-black text-2xl text-gradient-animated">
                CoachVision AI
              </span>
            </div>

            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center space-x-2">
              {navigation.map((item) => {
                const Icon = item.icon;
                const isActive = location.pathname === item.href;
                return (
                  <button
                    key={item.name}
                    onClick={() => navigate(item.href)}
                    className={`group flex items-center space-x-3 px-4 py-3 rounded-xl transition-all duration-300 font-medium hover-lift ${
                      isActive
                        ? 'bg-gradient-to-r from-blue-500 to-purple-500 text-white shadow-lg'
                        : 'text-gray-700 hover:text-blue-600 hover:bg-white/50'
                    }`}
                  >
                    <Icon className={`w-5 h-5 transition-transform duration-300 ${isActive ? '' : 'group-hover:scale-110'}`} />
                    <span>{item.name}</span>
                  </button>
                );
              })}
            </div>

            {/* User Menu */}
            <div className="flex items-center space-x-4">
              {profile && (
                <div className="hidden md:flex items-center space-x-4 glass px-4 py-2 rounded-xl">
                  {profile.mochaUser?.google_user_data?.picture && (
                    <img
                      src={profile.mochaUser.google_user_data.picture}
                      alt="Profile"
                      className="w-10 h-10 rounded-full shadow-lg hover-scale transition-transform duration-300"
                    />
                  )}
                  <div className="text-sm">
                    <div className="font-bold text-gray-900">
                      {profile.mochaUser?.google_user_data?.name || profile.user.email}
                    </div>
                    <div className="text-gray-600 capitalize flex items-center space-x-2">
                      <span>{profile.user.role}</span>
                      <span>•</span>
                      <span className={`px-2 py-1 rounded-full text-xs font-semibold ${
                        profile.user.subscription_plan === 'pro' 
                          ? 'bg-gradient-to-r from-gold-400 to-gold-500 text-white' 
                          : 'bg-gray-100 text-gray-600'
                      }`}>
                        {profile.user.subscription_plan}
                      </span>
                    </div>
                  </div>
                </div>
              )}
              
              <button
                onClick={handleLogout}
                className="hidden md:flex items-center space-x-2 text-gray-700 hover:text-red-600 transition-all duration-300 hover-lift px-3 py-2 rounded-lg"
              >
                <LogOut className="w-5 h-5" />
                <span className="font-medium">Logout</span>
              </button>

              {/* Mobile menu button */}
              <button
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                className="md:hidden p-3 rounded-xl text-gray-700 hover:bg-white/50 transition-all duration-300"
              >
                {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>

          {/* Enhanced Mobile Navigation */}
          {isMobileMenuOpen && (
            <div className="md:hidden py-6 border-t border-white/20">
              <div className="space-y-3">
                {navigation.map((item) => {
                  const Icon = item.icon;
                  const isActive = location.pathname === item.href;
                  return (
                    <button
                      key={item.name}
                      onClick={() => {
                        navigate(item.href);
                        setIsMobileMenuOpen(false);
                      }}
                      className={`w-full flex items-center space-x-4 px-4 py-3 rounded-xl transition-all duration-300 font-medium ${
                        isActive
                          ? 'bg-gradient-to-r from-blue-500 to-purple-500 text-white shadow-lg'
                          : 'text-gray-700 hover:text-blue-600 hover:bg-white/50'
                      }`}
                    >
                      <Icon className="w-5 h-5" />
                      <span>{item.name}</span>
                    </button>
                  );
                })}
                <hr className="my-4 border-white/20" />
                {profile && (
                  <div className="flex items-center space-x-4 px-4 py-3 glass rounded-xl mb-3">
                    {profile.mochaUser?.google_user_data?.picture && (
                      <img
                        src={profile.mochaUser.google_user_data.picture}
                        alt="Profile"
                        className="w-10 h-10 rounded-full shadow-lg"
                      />
                    )}
                    <div className="flex-1 text-sm">
                      <div className="font-bold text-gray-900">
                        {profile.mochaUser?.google_user_data?.name || profile.user.email}
                      </div>
                      <div className="text-gray-600 capitalize">
                        {profile.user.role} • {profile.user.subscription_plan}
                      </div>
                    </div>
                  </div>
                )}
                <button
                  onClick={handleLogout}
                  className="w-full flex items-center space-x-4 px-4 py-3 text-gray-700 hover:text-red-600 transition-all duration-300 rounded-xl hover:bg-red-50"
                >
                  <LogOut className="w-5 h-5" />
                  <span className="font-medium">Logout</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </nav>

      {/* Main Content */}
      <main className="relative z-10 flex-1">
        {children}
      </main>
    </div>
  );
}
