import { useState, useEffect } from 'react';
import { useAuth } from '@getmocha/users-service/react';
import type { User } from '@/shared/types';
import type { MochaUser } from '@getmocha/users-service/shared';

interface ProfileData {
  user: User;
  mochaUser: MochaUser;
}

export function useProfile() {
  const { user: mochaUser, isPending } = useAuth();
  const [profile, setProfile] = useState<ProfileData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!isPending && mochaUser) {
      fetchProfile();
    } else if (!isPending && !mochaUser) {
      setLoading(false);
      setProfile(null);
    }
  }, [mochaUser, isPending]);

  const fetchProfile = async () => {
    try {
      setError(null);
      const response = await fetch('/api/users/profile');
      if (response.ok) {
        const data = await response.json();
        setProfile(data);
      } else {
        const errorData = await response.json();
        setError(errorData.error || 'Failed to fetch profile');
      }
    } catch (error) {
      console.error('Failed to fetch profile:', error);
      setError('Network error while fetching profile');
    } finally {
      setLoading(false);
    }
  };

  return {
    profile,
    loading: loading || isPending,
    error,
    refetch: fetchProfile,
  };
}
