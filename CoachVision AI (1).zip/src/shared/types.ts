import z from "zod";

// User schemas
export const UserRoleSchema = z.enum(['athlete', 'coach']);
export const SubscriptionPlanSchema = z.enum(['free', 'pro']);

export const UserSchema = z.object({
  id: z.number(),
  mocha_user_id: z.string(),
  email: z.string(),
  name: z.string().nullable(),
  role: UserRoleSchema,
  subscription_plan: SubscriptionPlanSchema,
  analyses_used_this_week: z.number(),
  week_reset_date: z.string().nullable(),
  profile_picture_url: z.string().nullable(),
  created_at: z.string(),
  updated_at: z.string(),
});

// Video schemas
export const ActivityTypeSchema = z.enum(['running', 'kicking', 'jumping']);
export const VideoStatusSchema = z.enum(['uploaded', 'processing', 'completed', 'failed']);

export const VideoSchema = z.object({
  id: z.number(),
  user_id: z.number(),
  title: z.string(),
  description: z.string().nullable(),
  video_url: z.string(),
  thumbnail_url: z.string().nullable(),
  activity_type: ActivityTypeSchema,
  status: VideoStatusSchema,
  file_size_bytes: z.number().nullable(),
  duration_seconds: z.number().nullable(),
  created_at: z.string(),
  updated_at: z.string(),
});

// Analysis schemas
export const AnalysisResultSchema = z.object({
  id: z.number(),
  video_id: z.number(),
  user_id: z.number(),
  overall_score: z.number().nullable(),
  movement_quality_score: z.number().nullable(),
  technique_score: z.number().nullable(),
  consistency_score: z.number().nullable(),
  pose_data: z.string().nullable(), // JSON string
  improvement_tips: z.string().nullable(), // JSON array
  detected_errors: z.string().nullable(), // JSON array
  benchmark_comparison: z.string().nullable(), // JSON object
  processing_time_ms: z.number().nullable(),
  created_at: z.string(),
  updated_at: z.string(),
});

// Coach feedback schemas
export const CoachFeedbackSchema = z.object({
  id: z.number(),
  analysis_result_id: z.number(),
  coach_id: z.number(),
  athlete_id: z.number(),
  feedback_text: z.string(),
  recommendations: z.string().nullable(), // JSON array
  focus_areas: z.string().nullable(), // JSON array
  is_read: z.boolean(),
  created_at: z.string(),
  updated_at: z.string(),
});

// Coach group schemas
export const CoachGroupSchema = z.object({
  id: z.number(),
  coach_id: z.number(),
  name: z.string(),
  description: z.string().nullable(),
  invite_code: z.string().nullable(),
  is_active: z.boolean(),
  created_at: z.string(),
  updated_at: z.string(),
});

export const GroupMembershipSchema = z.object({
  id: z.number(),
  group_id: z.number(),
  athlete_id: z.number(),
  joined_at: z.string(),
  is_active: z.boolean(),
  created_at: z.string(),
  updated_at: z.string(),
});

// API request/response schemas
export const VideoUploadRequestSchema = z.object({
  title: z.string().min(1),
  description: z.string().optional(),
  activity_type: ActivityTypeSchema,
});

export const AnalysisRequestSchema = z.object({
  video_id: z.number(),
});

export const CoachFeedbackCreateSchema = z.object({
  analysis_result_id: z.number(),
  athlete_id: z.number(),
  feedback_text: z.string().min(1),
  recommendations: z.array(z.string()).optional(),
  focus_areas: z.array(z.string()).optional(),
});

// Type exports
export type User = z.infer<typeof UserSchema>;
export type UserRole = z.infer<typeof UserRoleSchema>;
export type SubscriptionPlan = z.infer<typeof SubscriptionPlanSchema>;
export type Video = z.infer<typeof VideoSchema>;
export type ActivityType = z.infer<typeof ActivityTypeSchema>;
export type VideoStatus = z.infer<typeof VideoStatusSchema>;
export type AnalysisResult = z.infer<typeof AnalysisResultSchema>;
export type CoachFeedback = z.infer<typeof CoachFeedbackSchema>;
export type CoachGroup = z.infer<typeof CoachGroupSchema>;
export type GroupMembership = z.infer<typeof GroupMembershipSchema>;
export type VideoUploadRequest = z.infer<typeof VideoUploadRequestSchema>;
export type AnalysisRequest = z.infer<typeof AnalysisRequestSchema>;
export type CoachFeedbackCreate = z.infer<typeof CoachFeedbackCreateSchema>;

// AI Analysis interfaces
export interface PoseData {
  keypoints: Array<{
    x: number;
    y: number;
    confidence: number;
    name: string;
  }>;
  timestamp: number;
}

export interface ImprovementTip {
  category: string;
  message: string;
  severity: 'low' | 'medium' | 'high';
  confidence: number;
}

export interface DetectedError {
  type: string;
  description: string;
  severity: 'low' | 'medium' | 'high';
  timestamp: number;
  confidence: number;
}

export interface BenchmarkComparison {
  professional_average: number;
  user_score: number;
  percentile: number;
  areas_for_improvement: string[];
}
