import { Hono } from "hono";
import { cors } from "hono/cors";
import {
  exchangeCodeForSessionToken,
  getOAuthRedirectUrl,
  deleteSession,
  MOCHA_SESSION_TOKEN_COOKIE_NAME,
} from "@getmocha/users-service/backend";
import { getCookie, setCookie } from "hono/cookie";
import OpenAI from "openai";
import {
  UserSchema,
  VideoUploadRequestSchema,
  AnalysisRequestSchema,
  CoachFeedbackCreateSchema,
  type User,
} from "@/shared/types";

interface Env {
  DB: any;
  OPENAI_API_KEY: string;
  MOCHA_USERS_SERVICE_API_URL: string;
  MOCHA_USERS_SERVICE_API_KEY: string;
}

const app = new Hono<{ Bindings: Env }>();

// CORS middleware
app.use("/*", cors({
  origin: "*",
  allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
  allowHeaders: ["Content-Type", "Authorization"],
  credentials: true,
}));

// Helper function to get auth config
function getAuthConfig(env: Env) {
  return {
    apiUrl: env.MOCHA_USERS_SERVICE_API_URL,
    apiKey: env.MOCHA_USERS_SERVICE_API_KEY,
  };
}

// Helper function to authenticate user
async function authenticateUser(c: any) {
  const sessionToken = getCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME);
  if (!sessionToken) {
    return null;
  }

  const { getCurrentUser } = await import("@getmocha/users-service/backend");
  return await getCurrentUser(sessionToken, getAuthConfig(c.env));
}

// OpenAI client helper
function getOpenAIClient(env: Env) {
  return new OpenAI({
    apiKey: env.OPENAI_API_KEY,
  });
}

// Authentication endpoints
app.get('/api/oauth/google/redirect_url', async (c) => {
  const redirectUrl = await getOAuthRedirectUrl('google', {
    apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
    apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
  });

  return c.json({ redirectUrl }, 200);
});

app.post("/api/sessions", async (c) => {
  const body = await c.req.json();

  if (!body.code) {
    return c.json({ error: "No authorization code provided" }, 400);
  }

  try {
    const sessionToken = await exchangeCodeForSessionToken(body.code, {
      apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
      apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
    });

    setCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME, sessionToken, {
      httpOnly: true,
      path: "/",
      sameSite: "none",
      secure: true,
      maxAge: 60 * 24 * 60 * 60, // 60 days
    });

    return c.json({ success: true }, 200);
  } catch (error) {
    console.error('Session creation error:', error);
    return c.json({ error: "Failed to create session" }, 400);
  }
});

app.get("/api/users/me", async (c) => {
  try {
    const mochaUser = await authenticateUser(c);
    if (!mochaUser) {
      return c.json({ error: "Invalid session" }, 401);
    }

    return c.json(mochaUser);
  } catch (error) {
    console.error("Auth error:", error);
    return c.json({ error: "Authentication failed" }, 401);
  }
});

app.get("/api/users/profile", async (c) => {
  try {
    const mochaUser = await authenticateUser(c);
    if (!mochaUser) {
      return c.json({ error: "Invalid session" }, 401);
    }

    // Get or create user in our database
    const { results } = await c.env.DB.prepare(
      "SELECT * FROM users WHERE mocha_user_id = ?"
    ).bind(mochaUser.id).all();

    let user: User;
    
    if (results.length === 0) {
      // Create new user
      const insertResult = await c.env.DB.prepare(`
        INSERT INTO users (mocha_user_id, email, name, role, subscription_plan, profile_picture_url)
        VALUES (?, ?, ?, 'athlete', 'free', ?)
        RETURNING *
      `).bind(
        mochaUser.id,
        mochaUser.email,
        mochaUser.google_user_data.name || null,
        mochaUser.google_user_data.picture || null
      ).first();

      user = UserSchema.parse(insertResult);
    } else {
      user = UserSchema.parse(results[0]);
    }

    return c.json({ user, mochaUser });
  } catch (error) {
    console.error("Auth error:", error);
    return c.json({ error: "Authentication failed" }, 401);
  }
});

app.get('/api/logout', async (c) => {
  const sessionToken = getCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME);

  if (typeof sessionToken === 'string') {
    await deleteSession(sessionToken, {
      apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
      apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
    });
  }

  setCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME, '', {
    httpOnly: true,
    path: '/',
    sameSite: 'none',
    secure: true,
    maxAge: 0,
  });

  return c.json({ success: true }, 200);
});

// User management endpoints
app.put("/api/users/profile", async (c) => {
  try {
    const mochaUser = await authenticateUser(c);
    if (!mochaUser) {
      return c.json({ error: "Invalid session" }, 401);
    }

    const body = await c.req.json();
    const { role } = body;

    if (role && !['athlete', 'coach'].includes(role)) {
      return c.json({ error: "Invalid role" }, 400);
    }

    const result = await c.env.DB.prepare(`
      UPDATE users 
      SET role = COALESCE(?, role), updated_at = CURRENT_TIMESTAMP
      WHERE mocha_user_id = ?
      RETURNING *
    `).bind(role, mochaUser.id).first();

    if (!result) {
      return c.json({ error: "User not found" }, 404);
    }

    return c.json({ user: UserSchema.parse(result) });
  } catch (error) {
    console.error("Auth error:", error);
    return c.json({ error: "Authentication failed" }, 401);
  }
});

// Video endpoints
app.get("/api/videos", async (c) => {
  try {
    const mochaUser = await authenticateUser(c);
    if (!mochaUser) {
      return c.json({ error: "Invalid session" }, 401);
    }

    const userResult = await c.env.DB.prepare(
      "SELECT id FROM users WHERE mocha_user_id = ?"
    ).bind(mochaUser.id).first();

    if (!userResult) {
      return c.json({ error: "User not found" }, 404);
    }

    const { results } = await c.env.DB.prepare(`
      SELECT v.*, ar.overall_score, ar.created_at as analysis_date
      FROM videos v
      LEFT JOIN analysis_results ar ON v.id = ar.video_id
      WHERE v.user_id = ?
      ORDER BY v.created_at DESC
    `).bind(userResult.id).all();

    return c.json({ videos: results });
  } catch (error) {
    console.error("Auth error:", error);
    return c.json({ error: "Authentication failed" }, 401);
  }
});

app.post("/api/videos", async (c) => {
  try {
    const mochaUser = await authenticateUser(c);
    if (!mochaUser) {
      return c.json({ error: "Invalid session" }, 401);
    }

    const userResult = await c.env.DB.prepare(
      "SELECT * FROM users WHERE mocha_user_id = ?"
    ).bind(mochaUser.id).first();

    if (!userResult) {
      return c.json({ error: "User not found" }, 404);
    }

    const user = UserSchema.parse(userResult);

    // Check subscription limits
    if (user.subscription_plan === 'free' && user.analyses_used_this_week >= 3) {
      return c.json({ 
        error: "Free plan limit reached. Upgrade to Pro for unlimited analyses." 
      }, 403);
    }

    const body = await c.req.json();
    const validatedData = VideoUploadRequestSchema.parse(body);

    // For MVP, we'll use a placeholder video URL
    // In production, this would handle file upload to R2
    const videoUrl = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4";

    const result = await c.env.DB.prepare(`
      INSERT INTO videos (user_id, title, description, video_url, activity_type, status)
      VALUES (?, ?, ?, ?, ?, 'uploaded')
      RETURNING *
    `).bind(
      user.id,
      validatedData.title,
      validatedData.description || null,
      videoUrl,
      validatedData.activity_type
    ).first();

    return c.json({ video: result });
  } catch (error) {
    console.error("Auth error:", error);
    return c.json({ error: "Authentication failed" }, 401);
  }
});

// AI Analysis endpoints
app.post("/api/analysis/movement", async (c) => {
  try {
    const mochaUser = await authenticateUser(c);
    if (!mochaUser) {
      return c.json({ error: "Invalid session" }, 401);
    }

    const userResult = await c.env.DB.prepare(
      "SELECT * FROM users WHERE mocha_user_id = ?"
    ).bind(mochaUser.id).first();

    if (!userResult) {
      return c.json({ error: "User not found" }, 404);
    }

    const user = UserSchema.parse(userResult);
    const body = await c.req.json();
    const { video_id } = AnalysisRequestSchema.parse(body);

    // Get video details
    const video = await c.env.DB.prepare(
      "SELECT * FROM videos WHERE id = ? AND user_id = ?"
    ).bind(video_id, user.id).first();

    if (!video) {
      return c.json({ error: "Video not found" }, 404);
    }

    // Check subscription limits
    if (user.subscription_plan === 'free' && user.analyses_used_this_week >= 3) {
      return c.json({ 
        error: "Free plan limit reached. Upgrade to Pro for unlimited analyses." 
      }, 403);
    }

    try {
      // Update video status
      await c.env.DB.prepare(
        "UPDATE videos SET status = 'processing' WHERE id = ?"
      ).bind(video_id).run();

      const startTime = Date.now();
      
      // AI Analysis using OpenAI (simulated for MVP)
      const openai = getOpenAIClient(c.env);
      
      const analysisPrompt = `
      Analyze this ${video.activity_type} performance video and provide detailed feedback.
      
      Please provide a JSON response with the following structure:
      {
        "overall_score": number (0-100),
        "movement_quality_score": number (0-100),
        "technique_score": number (0-100),
        "consistency_score": number (0-100),
        "improvement_tips": [
          {
            "category": "string",
            "message": "string",
            "severity": "low|medium|high",
            "confidence": number (0-1)
          }
        ],
        "detected_errors": [
          {
            "type": "string",
            "description": "string",
            "severity": "low|medium|high",
            "timestamp": number,
            "confidence": number (0-1)
          }
        ],
        "benchmark_comparison": {
          "professional_average": number,
          "user_score": number,
          "percentile": number,
          "areas_for_improvement": ["string"]
        }
      }
      
      Base the analysis on common ${video.activity_type} technique principles.
      `;

      const response = await openai.chat.completions.create({
        model: "gpt-4o-mini",
        messages: [
          { role: "system", content: "You are an expert sports performance analyst specializing in biomechanics and movement analysis." },
          { role: "user", content: analysisPrompt }
        ],
        response_format: { type: "json_object" },
        temperature: 0.7,
      });

      const analysisData = JSON.parse(response.choices[0].message.content || '{}');
      const processingTime = Date.now() - startTime;

      // Save analysis results
      const analysisResult = await c.env.DB.prepare(`
        INSERT INTO analysis_results (
          video_id, user_id, overall_score, movement_quality_score, 
          technique_score, consistency_score, pose_data, improvement_tips,
          detected_errors, benchmark_comparison, processing_time_ms
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        RETURNING *
      `).bind(
        video_id,
        user.id,
        analysisData.overall_score,
        analysisData.movement_quality_score,
        analysisData.technique_score,
        analysisData.consistency_score,
        JSON.stringify([]), // Mock pose data for MVP
        JSON.stringify(analysisData.improvement_tips),
        JSON.stringify(analysisData.detected_errors),
        JSON.stringify(analysisData.benchmark_comparison),
        processingTime
      ).first();

      // Update video status and user usage
      await c.env.DB.prepare(
        "UPDATE videos SET status = 'completed' WHERE id = ?"
      ).bind(video_id).run();

      if (user.subscription_plan === 'free') {
        await c.env.DB.prepare(
          "UPDATE users SET analyses_used_this_week = analyses_used_this_week + 1 WHERE id = ?"
        ).bind(user.id).run();
      }

      return c.json({ 
        analysis: analysisResult,
        message: "Analysis completed successfully" 
      });

    } catch (error) {
      console.error('Analysis error:', error);
      
      // Update video status to failed
      await c.env.DB.prepare(
        "UPDATE videos SET status = 'failed' WHERE id = ?"
      ).bind(video_id).run();

      return c.json({ error: "Analysis failed" }, 500);
    }
  } catch (error) {
    console.error("Auth error:", error);
    return c.json({ error: "Authentication failed" }, 401);
  }
});

app.get("/api/analysis/:videoId", async (c) => {
  try {
    const mochaUser = await authenticateUser(c);
    if (!mochaUser) {
      return c.json({ error: "Invalid session" }, 401);
    }

    const videoId = c.req.param('videoId');
    
    const userResult = await c.env.DB.prepare(
      "SELECT id FROM users WHERE mocha_user_id = ?"
    ).bind(mochaUser.id).first();

    if (!userResult) {
      return c.json({ error: "User not found" }, 404);
    }

    const result = await c.env.DB.prepare(`
      SELECT ar.*, v.title, v.activity_type, v.video_url
      FROM analysis_results ar
      JOIN videos v ON ar.video_id = v.id
      WHERE ar.video_id = ? AND ar.user_id = ?
    `).bind(videoId, userResult.id).first();

    if (!result) {
      return c.json({ error: "Analysis not found" }, 404);
    }

    return c.json({ analysis: result });
  } catch (error) {
    console.error("Auth error:", error);
    return c.json({ error: "Authentication failed" }, 401);
  }
});

// Coach feedback endpoints (for Pro users)
app.post("/api/coach/feedback", async (c) => {
  try {
    const mochaUser = await authenticateUser(c);
    if (!mochaUser) {
      return c.json({ error: "Invalid session" }, 401);
    }

    const userResult = await c.env.DB.prepare(
      "SELECT * FROM users WHERE mocha_user_id = ?"
    ).bind(mochaUser.id).first();

    if (!userResult) {
      return c.json({ error: "User not found" }, 404);
    }

    const user = UserSchema.parse(userResult);

    if (user.role !== 'coach' || user.subscription_plan !== 'pro') {
      return c.json({ error: "Coach Pro subscription required" }, 403);
    }

    const body = await c.req.json();
    const validatedData = CoachFeedbackCreateSchema.parse(body);

    const result = await c.env.DB.prepare(`
      INSERT INTO coach_feedback (
        analysis_result_id, coach_id, athlete_id, feedback_text, 
        recommendations, focus_areas
      ) VALUES (?, ?, ?, ?, ?, ?)
      RETURNING *
    `).bind(
      validatedData.analysis_result_id,
      user.id,
      validatedData.athlete_id,
      validatedData.feedback_text,
      JSON.stringify(validatedData.recommendations || []),
      JSON.stringify(validatedData.focus_areas || [])
    ).first();

    return c.json({ feedback: result });
  } catch (error) {
    console.error("Auth error:", error);
    return c.json({ error: "Authentication failed" }, 401);
  }
});

// Health check
app.get("/api/health", (c) => {
  return c.json({ status: "OK", timestamp: new Date().toISOString() });
});

export default app;
